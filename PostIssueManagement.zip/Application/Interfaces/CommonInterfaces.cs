using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Application.Interfaces {
    public interface IRepository<T> where T : class {
        Task<T?> GetByIdAsync(object id);
        Task<IEnumerable<T>> GetAllAsync();
        Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> predicate);
        Task AddAsync(T entity);
        void Update(T entity);
        void Remove(T entity);
    }

    public interface IUnitOfWork {
        IRepository<Domain.Entities.User> Users { get; }
        IRepository<Domain.Entities.Role> Roles { get; }
        IRepository<Domain.Entities.UserRole> UserRoles { get; }
        IRepository<Domain.Entities.Post> Posts { get; }
        IRepository<Domain.Entities.Comment> Comments { get; }
        IRepository<Domain.Entities.AuditLog> AuditLogs { get; }
        Task<int> SaveChangesAsync();
    }
}
