using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Application.DTO;

namespace Application.Interfaces {
    public interface IAuthService {
        Task<(string token, UserDto user)> RegisterAsync(RegisterRequestDto dto);
        Task<(string token, UserDto user)> LoginAsync(LoginRequestDto dto);
        Task<UserDto?> GetMeAsync(Guid userId);
    }

    public interface IPostService {
        Task<PostDto> CreateAsync(Guid userId, CreatePostDto dto);
        Task<PostDto> SubmitForApprovalAsync(Guid userId, Guid postId);
        Task<PostDto> ApproveAsync(Guid adminId, Guid postId);
        Task<PostDto> RejectAsync(Guid adminId, Guid postId);
        Task<PostDto> AssignAsync(Guid adminId, Guid postId, Guid assigneeUserId);
        Task<PostDto> CloseAsync(Guid adminId, Guid postId);
        Task<IEnumerable<PostDto>> ListAsync(string? status = null, string? type = null);
        Task<PostDto?> GetByIdAsync(Guid postId);
    }

    public interface ICommentService {
        Task<CommentDto> AddAsync(Guid userId, Guid postId, CreateCommentDto dto);
        Task<IEnumerable<CommentDto>> GetForPostAsync(Guid postId);
    }

    public interface IAdminService {
        Task<bool> PromoteAsync(Guid superAdminId, Guid userId, string role);
        Task<bool> DemoteAsync(Guid superAdminId, Guid userId, string role);
        Task<bool> RemoveUserAsync(Guid superAdminId, Guid userId);
    }

    public interface ITokenService {
        string GenerateToken(Domain.Entities.User user, IEnumerable<string> roles);
    }
}
