using System;

namespace Application.DTO {
    public class RoleChangeDto {
        public Guid UserId { get; set; }
        public string Role { get; set; } = string.Empty; // ADMIN or USER
    }
}
