using System;

namespace Application.DTO {
    public class CreateCommentDto {
        public string Content { get; set; } = string.Empty;
    }
    public class CommentDto {
        public Guid Id { get; set; }
        public Guid PostId { get; set; }
        public string CreatedByUserId { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
