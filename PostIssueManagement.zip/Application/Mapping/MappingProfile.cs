using AutoMapper;
using Domain.Entities;
using Application.DTO;

namespace Application.Mapping {
    public class MappingProfile : Profile {
        public MappingProfile() {
            CreateMap<Post, PostDto>();
            CreateMap<Comment, CommentDto>();
        }
    }
}
