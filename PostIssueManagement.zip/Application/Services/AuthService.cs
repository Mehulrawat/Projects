using System;
using System.Linq;
using System.Threading.Tasks;
using Application.DTO;
using Application.Interfaces;
using Application.Exceptions;
using AutoMapper;
using Domain.Entities;
using Domain.Entities.Enums;
using Microsoft.AspNetCore.Identity;

namespace Application.Services {
    public class AuthService : IAuthService {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly ITokenService _tokenService;
        private readonly IPasswordHasher<User> _hasher;
        private readonly int _inactivityDays;

        public AuthService(IUnitOfWork uow, IMapper mapper, ITokenService tokenService, IPasswordHasher<User> hasher, int inactivityDays = 90){
            _uow = uow; _mapper = mapper; _tokenService = tokenService; _hasher = hasher; _inactivityDays = inactivityDays;
        }

        public async Task<(string token, UserDto user)> RegisterAsync(RegisterRequestDto dto){
            var exists = (await _uow.Users.FindAsync(u => u.Email == dto.Email)).FirstOrDefault();
            if (exists != null) throw new ValidationException("Email already registered");
            var user = new User { UserName = dto.UserName, Email = dto.Email };
            user.PasswordHash = _hasher.HashPassword(user, dto.Password);
            await _uow.Users.AddAsync(user);
            // assign USER role by default
            var role = (await _uow.Roles.FindAsync(r => r.Name == RoleNames.User)).FirstOrDefault();
            if (role == null){ role = new Role { Name = RoleNames.User }; await _uow.Roles.AddAsync(role);}            
            await _uow.UserRoles.AddAsync(new UserRole { UserId = user.Id, RoleId = role.Id, User = user, Role = role });
            await _uow.SaveChangesAsync();
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name);
            var token = _tokenService.GenerateToken(user, roles);
            var dtoUser = new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles.ToArray(), IsActive = user.IsActive, IsExpired = user.IsExpired };
            return (token, dtoUser);
        }

        public async Task<(string token, UserDto user)> LoginAsync(LoginRequestDto dto){
            var user = (await _uow.Users.FindAsync(u => u.Email == dto.Email)).FirstOrDefault();
            if (user == null) throw new UnauthorizedException("Invalid credentials");
            // inactivity check
            if (user.LastActiveAt.HasValue && user.LastActiveAt.Value < DateTime.UtcNow.AddDays(-_inactivityDays)){
                user.IsExpired = true; user.IsActive = false; _uow.Users.Update(user); await _uow.SaveChangesAsync();
                throw new ForbiddenException("Account expired due to inactivity");
            }
            var res = _hasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (res == PasswordVerificationResult.Failed) throw new UnauthorizedException("Invalid credentials");
            user.LastActiveAt = DateTime.UtcNow; _uow.Users.Update(user); await _uow.SaveChangesAsync();
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name);
            var token = _tokenService.GenerateToken(user, roles);
            var dtoUser = new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles.ToArray(), IsActive = user.IsActive, IsExpired = user.IsExpired };
            return (token, dtoUser);
        }

        public async Task<UserDto?> GetMeAsync(Guid userId){
            var user = await _uow.Users.GetByIdAsync(userId);
            if (user == null) return null;
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name).ToArray();
            return new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles, IsActive = user.IsActive, IsExpired = user.IsExpired };
        }
    }
}
