using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.DTO;
using Application.Interfaces;
using Application.Exceptions;
using AutoMapper;
using Domain.Entities;

namespace Application.Services {
    public class CommentService : ICommentService {
        private readonly IUnitOfWork _uow; private readonly IMapper _mapper;
        public CommentService(IUnitOfWork uow, IMapper mapper){ _uow = uow; _mapper = mapper; }
        public async Task<CommentDto> AddAsync(Guid userId, Guid postId, CreateCommentDto dto){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            var user = await _uow.Users.GetByIdAsync(userId); if (user == null) throw new NotFoundException("User not found");
            var comment = new Comment { PostId = postId, CreatedByUserId = userId, Content = dto.Content };
            await _uow.Comments.AddAsync(comment); await _uow.SaveChangesAsync();
            return _mapper.Map<CommentDto>(comment);
        }
        public async Task<IEnumerable<CommentDto>> GetForPostAsync(Guid postId){
            var comments = await _uow.Comments.FindAsync(c => c.PostId == postId);
            return comments.Select(c => _mapper.Map<CommentDto>(c));
        }
    }
}
