using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.DTO;
using Application.Interfaces;
using Application.Exceptions;
using AutoMapper;
using Domain.Entities;
using Domain.Entities.Enums;

namespace Application.Services {
    public class PostService : IPostService {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        public PostService(IUnitOfWork uow, IMapper mapper){ _uow = uow; _mapper = mapper; }

        public async Task<PostDto> CreateAsync(Guid userId, CreatePostDto dto){
            var user = await _uow.Users.GetByIdAsync(userId); if (user == null) throw new NotFoundException("User not found");
            var post = new Post { Title = dto.Title, Content = dto.Content, Type = dto.Type, Status = PostStatus.Draft, CreatedByUserId = userId };
            await _uow.Posts.AddAsync(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<PostDto> SubmitForApprovalAsync(Guid userId, Guid postId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            if (post.CreatedByUserId != userId) throw new ForbiddenException("Only creator can submit");
            post.Status = PostStatus.PendingApproval; post.UpdatedAt = DateTime.UtcNow; _uow.Posts.Update(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<PostDto> ApproveAsync(Guid adminId, Guid postId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            post.Status = PostStatus.Approved; post.UpdatedAt = DateTime.UtcNow; _uow.Posts.Update(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<PostDto> RejectAsync(Guid adminId, Guid postId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            post.Status = PostStatus.Rejected; post.UpdatedAt = DateTime.UtcNow; _uow.Posts.Update(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<PostDto> AssignAsync(Guid adminId, Guid postId, Guid assigneeUserId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            var assignee = await _uow.Users.GetByIdAsync(assigneeUserId); if (assignee == null) throw new NotFoundException("Assignee not found");
            post.AssignedToUserId = assigneeUserId; post.UpdatedAt = DateTime.UtcNow; _uow.Posts.Update(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<PostDto> CloseAsync(Guid adminId, Guid postId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) throw new NotFoundException("Post not found");
            post.Status = PostStatus.Closed; post.UpdatedAt = DateTime.UtcNow; _uow.Posts.Update(post); await _uow.SaveChangesAsync();
            return _mapper.Map<PostDto>(post);
        }
        public async Task<IEnumerable<PostDto>> ListAsync(string? status = null, string? type = null){
            var all = await _uow.Posts.GetAllAsync();
            if (!string.IsNullOrEmpty(status)){
                if (Enum.TryParse<PostStatus>(status, true, out var s)) all = all.Where(p => p.Status == s);
            }
            if (!string.IsNullOrEmpty(type)){
                if (Enum.TryParse<PostType>(type, true, out var t)) all = all.Where(p => p.Type == t);
            }
            return all.Select(p => _mapper.Map<PostDto>(p));
        }
        public async Task<PostDto?> GetByIdAsync(Guid postId){
            var post = await _uow.Posts.GetByIdAsync(postId); if (post == null) return null; return _mapper.Map<PostDto>(post);
        }
    }
}
