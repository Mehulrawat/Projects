using System;
using System.Linq;
using System.Threading.Tasks;
using Application.Interfaces;
using Application.Exceptions;
using Domain.Entities;
using Domain.Entities.Enums;

namespace Application.Services {
    public class AdminService : IAdminService {
        private readonly IUnitOfWork _uow;
        public AdminService(IUnitOfWork uow){ _uow = uow; }
        public async Task<bool> PromoteAsync(Guid superAdminId, Guid userId, string role){
            var target = await _uow.Users.GetByIdAsync(userId); if (target == null) throw new NotFoundException("User not found");
            var r = (await _uow.Roles.FindAsync(x => x.Name == role)).FirstOrDefault();
            if (r == null){ r = new Role { Name = role }; await _uow.Roles.AddAsync(r); }
            var exists = (await _uow.UserRoles.FindAsync(ur => ur.UserId == userId && ur.RoleId == r.Id)).Any();
            if (!exists){ await _uow.UserRoles.AddAsync(new UserRole{ UserId = userId, RoleId = r.Id }); }
            await _uow.SaveChangesAsync();
            return true;
        }
        public async Task<bool> DemoteAsync(Guid superAdminId, Guid userId, string role){
            var r = (await _uow.Roles.FindAsync(x => x.Name == role)).FirstOrDefault(); if (r == null) return false;
            var entries = await _uow.UserRoles.FindAsync(ur => ur.UserId == userId && ur.RoleId == r.Id);
            foreach (var e in entries) _uow.UserRoles.Remove(e);
            await _uow.SaveChangesAsync();
            return true;
        }
        public async Task<bool> RemoveUserAsync(Guid superAdminId, Guid userId){
            var user = await _uow.Users.GetByIdAsync(userId); if (user == null) return false;
            _uow.Users.Remove(user); await _uow.SaveChangesAsync(); return true;
        }
    }
}
