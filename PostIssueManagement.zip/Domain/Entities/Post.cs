using System;
using System.Collections.Generic;
using Domain.Entities.Enums;

namespace Domain.Entities {
    public class Post {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public PostType Type { get; set; } = PostType.Announcement;
        public PostStatus Status { get; set; } = PostStatus.Draft;
        public Guid CreatedByUserId { get; set; }
        public User? CreatedBy { get; set; }
        public Guid? AssignedToUserId { get; set; }
        public User? AssignedTo { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }
        public ICollection<Comment> Comments { get; set; } = new List<Comment>();
    }
}
