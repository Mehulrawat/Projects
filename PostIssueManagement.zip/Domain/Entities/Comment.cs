using System;

namespace Domain.Entities {
    public class Comment {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid PostId { get; set; }
        public Post? Post { get; set; }
        public Guid CreatedByUserId { get; set; }
        public User? CreatedBy { get; set; }
        public string Content { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
