namespace Domain.Entities.Enums {
    public enum PostType {
        LostItem = 0,
        HelpRequest = 1,
        Announcement = 2,
        Complaint = 3,
        Issue = 4,
        Other = 5
    }
}
