namespace Domain.Entities.Enums {
    public enum PostStatus {
        Draft = 0,
        PendingApproval = 1,
        Approved = 2,
        Rejected = 3,
        Closed = 4
    }
}
