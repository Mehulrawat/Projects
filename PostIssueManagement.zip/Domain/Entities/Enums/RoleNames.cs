namespace Domain.Entities.Enums {
    public static class RoleNames {
        public const string User = "USER";
        public const string Admin = "ADMIN";
        public const string SuperAdmin = "SUPERADMIN";
    }
}
