using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Application.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Infrastructure.Repositories {
    public class GenericRepository<T> : IRepository<T> where T : class {
        protected readonly Infrastructure.Data.AppDbContext _ctx;
        protected readonly DbSet<T> _dbSet;
        public GenericRepository(Infrastructure.Data.AppDbContext ctx){ _ctx = ctx; _dbSet = _ctx.Set<T>(); }
        public async Task AddAsync(T entity){ await _dbSet.AddAsync(entity); }
        public async Task<IEnumerable<T>> GetAllAsync(){ return await _dbSet.ToListAsync(); }
        public async Task<T?> GetByIdAsync(object id){ return await _dbSet.FindAsync(id); }
        public async Task<IEnumerable<T>> FindAsync(Expression<Func<T, bool>> predicate){ return await _dbSet.Where(predicate).ToListAsync(); }
        public void Remove(T entity){ _dbSet.Remove(entity); }
        public void Update(T entity){ _dbSet.Update(entity); }
    }
}
