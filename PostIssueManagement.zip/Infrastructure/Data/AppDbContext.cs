using Microsoft.EntityFrameworkCore;
using Domain.Entities;
using Domain.Entities.Enums;

namespace Infrastructure.Data {
    public class AppDbContext : DbContext {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) {}
        public DbSet<User> Users => Set<User>();
        public DbSet<Role> Roles => Set<Role>();
        public DbSet<UserRole> UserRoles => Set<UserRole>();
        public DbSet<Post> Posts => Set<Post>();
        public DbSet<Comment> Comments => Set<Comment>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
        protected override void OnModelCreating(ModelBuilder modelBuilder){
            modelBuilder.Entity<UserRole>().HasKey(ur => new { ur.UserId, ur.RoleId });
            modelBuilder.Entity<UserRole>().HasOne(ur => ur.User).WithMany(u => u.UserRoles).HasForeignKey(ur => ur.UserId);
            modelBuilder.Entity<UserRole>().HasOne(ur => ur.Role).WithMany(r => r.UserRoles).HasForeignKey(ur => ur.RoleId);

            modelBuilder.Entity<Post>().HasOne(p => p.CreatedBy).WithMany(u => u.Posts).HasForeignKey(p => p.CreatedByUserId).OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Post>().HasOne(p => p.AssignedTo).WithMany().HasForeignKey(p => p.AssignedToUserId).OnDelete(DeleteBehavior.Restrict);
            modelBuilder.Entity<Comment>().HasOne(c => c.Post).WithMany(p => p.Comments).HasForeignKey(c => c.PostId);
            modelBuilder.Entity<Comment>().HasOne(c => c.CreatedBy).WithMany(u => u.Comments).HasForeignKey(c => c.CreatedByUserId).OnDelete(DeleteBehavior.Restrict);

            // seed roles
            modelBuilder.Entity<Role>().HasData(new Role{Id=1, Name=RoleNames.User}, new Role{Id=2, Name=RoleNames.Admin}, new Role{Id=3, Name=RoleNames.SuperAdmin});
        }
    }
}
