using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Entities;
using Infrastructure.Data;
using Infrastructure.Repositories;

namespace Infrastructure.Data {
    public class UnitOfWork : IUnitOfWork {
        private readonly AppDbContext _ctx;
        public IRepository<User> Users { get; }
        public IRepository<Role> Roles { get; }
        public IRepository<UserRole> UserRoles { get; }
        public IRepository<Post> Posts { get; }
        public IRepository<Comment> Comments { get; }
        public IRepository<AuditLog> AuditLogs { get; }
        public UnitOfWork(AppDbContext ctx){
            _ctx = ctx;
            Users = new GenericRepository<User>(ctx);
            Roles = new GenericRepository<Role>(ctx);
            UserRoles = new GenericRepository<UserRole>(ctx);
            Posts = new GenericRepository<Post>(ctx);
            Comments = new GenericRepository<Comment>(ctx);
            AuditLogs = new GenericRepository<AuditLog>(ctx);
        }
        public async Task<int> SaveChangesAsync(){ return await _ctx.SaveChangesAsync(); }
    }
}
