# PostIssueManagement (.NET 8)

A full-fledged Post / Issue Management System implementing Repository & UnitOfWork patterns, DTOs, role-based JWT security, workflow, and comments.

## Projects
- **Domain**: Entities & enums
- **Application**: DTOs, interfaces, services, mapping, exceptions
- **Infrastructure**: EF Core (SQLite), repositories, unit-of-work, token service
- **WebAPI**: REST controllers, middleware, swagger, seeding

## Run
```bash
cd PostIssueManagement/WebAPI
dotnet restore
dotnet run
```
Open Swagger: http://localhost:5000/swagger (or the port printed)

## Default Super Admin
- Email: `superadmin@system.local`
- Password: `SuperAdmin@123`

## API Highlights
- `POST /auth/register` — register
- `POST /auth/login` — login (returns JWT)
- `GET /auth/me` — current user
- `POST /posts` — create draft
- `POST /posts/{id}/submit` — submit for approval
- `POST /posts/{id}/approve` — approve (ADMIN/SUPERADMIN)
- `POST /posts/{id}/reject` — reject (ADMIN/SUPERADMIN)
- `POST /posts/{id}/assign/{assigneeId}` — assign (ADMIN/SUPERADMIN)
- `POST /posts/{id}/close` — close (ADMIN/SUPERADMIN)
- `POST /comments/{postId}` — add comment (auth)
- `GET /comments/{postId}` — list comments
- `POST /admin/promote` — promote to role (SUPERADMIN)
- `POST /admin/demote` — demote role (SUPERADMIN)
- `DELETE /admin/users/{userId}` — remove user (SUPERADMIN)

## Notes
- Account expiration after inactivity is enforced on login and via `ActivityMiddleware`.
- Database is SQLite file `post_issue_mgmt.db` created automatically.
- Change JWT secret in `WebAPI/appsettings.json`.
