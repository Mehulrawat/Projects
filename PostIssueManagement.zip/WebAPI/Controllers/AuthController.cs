using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Application.Interfaces;
using Application.DTO;
using Microsoft.AspNetCore.Authorization;

namespace WebAPI.Controllers {
    [ApiController]
    [Route("auth")]
    public class AuthController : ControllerBase {
        private readonly IAuthService _auth;
        public AuthController(IAuthService auth){ _auth = auth; }

        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDto dto){
            var (token, user) = await _auth.RegisterAsync(dto);
            return Ok(new { token, user });
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto dto){
            var (token, user) = await _auth.LoginAsync(dto);
            return Ok(new { token, user });
        }

        [HttpGet("me")]
        [Authorize]
        public async Task<IActionResult> Me(){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            if (sub == null) return Unauthorized();
            var userId = Guid.Parse(sub);
            var me = await _auth.GetMeAsync(userId);
            return Ok(me);
        }
    }
}
