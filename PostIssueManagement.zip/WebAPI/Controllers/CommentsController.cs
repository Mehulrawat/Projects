using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Application.Interfaces;
using Application.DTO;

namespace WebAPI.Controllers {
    [ApiController]
    [Route("comments")]
    public class CommentsController : ControllerBase {
        private readonly ICommentService _comments;
        public CommentsController(ICommentService comments){ _comments = comments; }

        [HttpPost("{postId}")]
        [Authorize]
        public async Task<IActionResult> Add(Guid postId, [FromBody] CreateCommentDto dto){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var c = await _comments.AddAsync(userId, postId, dto);
            return Ok(c);
        }

        [HttpGet("{postId}")]
        [AllowAnonymous]
        public async Task<IActionResult> List(Guid postId){
            var list = await _comments.GetForPostAsync(postId);
            return Ok(list);
        }
    }
}
