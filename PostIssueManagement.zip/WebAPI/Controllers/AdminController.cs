using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Application.Interfaces;
using Application.DTO;

namespace WebAPI.Controllers {
    [ApiController]
    [Route("admin")]
    public class AdminController : ControllerBase {
        private readonly IAdminService _admin;
        public AdminController(IAdminService admin){ _admin = admin; }

        [HttpPost("promote")]
        [Authorize(Policy="RequireSuperAdmin")]
        public async Task<IActionResult> Promote([FromBody] RoleChangeDto dto){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var me = Guid.Parse(sub!);
            var ok = await _admin.PromoteAsync(me, dto.UserId, dto.Role);
            return Ok(new { success = ok });
        }
        [HttpPost("demote")]
        [Authorize(Policy="RequireSuperAdmin")]
        public async Task<IActionResult> Demote([FromBody] RoleChangeDto dto){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var me = Guid.Parse(sub!);
            var ok = await _admin.DemoteAsync(me, dto.UserId, dto.Role);
            return Ok(new { success = ok });
        }
        [HttpDelete("users/{userId}")]
        [Authorize(Policy="RequireSuperAdmin")]
        public async Task<IActionResult> Remove(Guid userId){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var me = Guid.Parse(sub!);
            var ok = await _admin.RemoveUserAsync(me, userId);
            return Ok(new { success = ok });
        }
    }
}
