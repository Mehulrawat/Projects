using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Application.Interfaces;
using Application.DTO;

namespace WebAPI.Controllers {
    [ApiController]
    [Route("posts")]
    public class PostsController : ControllerBase {
        private readonly IPostService _posts;
        public PostsController(IPostService posts){ _posts = posts; }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Create([FromBody] CreatePostDto dto){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.CreateAsync(userId, dto);
            return Ok(post);
        }

        [HttpPost("{id}/submit")]
        [Authorize]
        public async Task<IActionResult> Submit(Guid id){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.SubmitForApprovalAsync(userId, id);
            return Ok(post);
        }

        [HttpPost("{id}/approve")]
        [Authorize(Policy="RequireAdmin")]
        public async Task<IActionResult> Approve(Guid id){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.ApproveAsync(userId, id);
            return Ok(post);
        }

        [HttpPost("{id}/reject")]
        [Authorize(Policy="RequireAdmin")]
        public async Task<IActionResult> Reject(Guid id){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.RejectAsync(userId, id);
            return Ok(post);
        }

        [HttpPost("{id}/assign/{assigneeId}")]
        [Authorize(Policy="RequireAdmin")]
        public async Task<IActionResult> Assign(Guid id, Guid assigneeId){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.AssignAsync(userId, id, assigneeId);
            return Ok(post);
        }

        [HttpPost("{id}/close")]
        [Authorize(Policy="RequireAdmin")]
        public async Task<IActionResult> Close(Guid id){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            var userId = Guid.Parse(sub!);
            var post = await _posts.CloseAsync(userId, id);
            return Ok(post);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] string? type){
            var list = await _posts.ListAsync(status, type);
            return Ok(list);
        }

        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> Get(Guid id){
            var post = await _posts.GetByIdAsync(id);
            return post == null ? NotFound() : Ok(post);
        }
    }
}
