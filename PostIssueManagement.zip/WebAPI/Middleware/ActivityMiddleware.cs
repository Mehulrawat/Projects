using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace WebAPI.Middleware {
    public class ActivityMiddleware {
        private readonly RequestDelegate _next;
        private readonly int _inactivityDays;
        public ActivityMiddleware(RequestDelegate next, IConfiguration config){ _next = next; _inactivityDays = config.GetValue<int>("Security:AccountInactivityDays"); }
        public async Task InvokeAsync(HttpContext context, AppDbContext db){
            if (context.User?.Identity?.IsAuthenticated == true){
                var sub = context.User.Claims.FirstOrDefault(c => c.Type == System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
                if (Guid.TryParse(sub, out var userId)){
                    var user = await db.Users.FirstOrDefaultAsync(u => u.Id == userId);
                    if (user != null){
                        // expire logic
                        if (user.LastActiveAt.HasValue && user.LastActiveAt.Value < DateTime.UtcNow.AddDays(-_inactivityDays)){
                            user.IsExpired = true; user.IsActive = false; db.Users.Update(user); await db.SaveChangesAsync();
                            context.Response.StatusCode = StatusCodes.Status403Forbidden;
                            await context.Response.WriteAsync("Account expired due to inactivity");
                            return;
                        }
                        user.LastActiveAt = DateTime.UtcNow;
                        db.Users.Update(user);
                        await db.SaveChangesAsync();
                    }
                }
            }
            await _next(context);
        }
    }
}
