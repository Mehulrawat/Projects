using System.Text;
using Application.Interfaces;
using Application.Services;
using Application.Mapping;
using Infrastructure.Data;
using Infrastructure.Security;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Identity;
using Domain.Entities;

var builder = WebApplication.CreateBuilder(args);

// DbContext
builder.Services.AddDbContext<AppDbContext>(opt => opt.UseSqlite(builder.Configuration.GetConnectionString("Default")));

// Unit of Work & Repositories
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

// AutoMapper
builder.Services.AddAutoMapper(typeof(MappingProfile));

// Password Hasher
builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();

// Token Service
builder.Services.AddScoped<ITokenService, TokenService>();

// Application Services
builder.Services.AddScoped<IAuthService, AuthService>(sp => {
    var uow = sp.GetRequiredService<IUnitOfWork>();
    var mapper = sp.GetRequiredService<AutoMapper.IMapper>();
    var token = sp.GetRequiredService<ITokenService>();
    var hasher = sp.GetRequiredService<IPasswordHasher<User>>();
    var inactivityDays = builder.Configuration.GetValue<int>("Security:AccountInactivityDays");
    return new AuthService(uow, mapper, token, hasher, inactivityDays);
});

builder.Services.AddScoped<IPostService, PostService>();
builder.Services.AddScoped<ICommentService, CommentService>();
builder.Services.AddScoped<IAdminService, AdminService>();

builder.Services.AddControllers();

// Authentication JWT
var key = builder.Configuration["Jwt:Key"]!;
var issuer = builder.Configuration["Jwt:Issuer"]!;
var audience = builder.Configuration["Jwt:Audience"]!;

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options => {
        options.TokenValidationParameters = new TokenValidationParameters {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = issuer,
            ValidAudience = audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))
        };
    });

builder.Services.AddAuthorization(options => {
    options.AddPolicy("RequireAdmin", policy => policy.RequireRole("ADMIN","SUPERADMIN"));
    options.AddPolicy("RequireSuperAdmin", policy => policy.RequireRole("SUPERADMIN"));
});

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => {
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "PostIssueManagement API", Version = "v1"});
    var securityScheme = new OpenApiSecurityScheme {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme."
    };
    c.AddSecurityDefinition("Bearer", securityScheme);
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
        { securityScheme, new List<string>() }
    });
});

var app = builder.Build();

// Ensure DB created & seed
using (var scope = app.Services.CreateScope()){
    var ctx = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    ctx.Database.EnsureCreated();
    await Seed.DataSeeder.SeedAsync(ctx, scope.ServiceProvider);
}

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

// Activity middleware
app.UseMiddleware<WebAPI.Middleware.ActivityMiddleware>();

app.MapControllers();

app.Run();
