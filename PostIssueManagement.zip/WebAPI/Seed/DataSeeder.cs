using System;
using System.Linq;
using System.Threading.Tasks;
using Domain.Entities;
using Domain.Entities.Enums;
using Infrastructure.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace Seed {
    public static class DataSeeder {
        public static async Task SeedAsync(AppDbContext ctx, IServiceProvider sp){
            // Ensure roles seeded (via modelBuilder)
            if (!ctx.Users.Any()){
                var hasher = sp.GetRequiredService<IPasswordHasher<User>>();
                var super = new User { UserName = "superadmin", Email = "superadmin@system.local" };
                super.PasswordHash = hasher.HashPassword(super, "SuperAdmin@123");
                ctx.Users.Add(super);
                await ctx.SaveChangesAsync();
                var sRole = ctx.Roles.First(r => r.Name == RoleNames.SuperAdmin);
                ctx.UserRoles.Add(new UserRole { UserId = super.Id, RoleId = sRole.Id });
                await ctx.SaveChangesAsync();
            }
        }
    }
}
