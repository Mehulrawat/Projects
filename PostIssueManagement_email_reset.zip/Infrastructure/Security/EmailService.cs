using System.Net.Mail;
using System.Net;
using System.Threading.Tasks;
using Application.Interfaces;
using Microsoft.Extensions.Configuration;
using System.IO;
using System;

namespace Infrastructure.Security {
    public class EmailService : IEmailService {
        private readonly IConfiguration _config;
        public EmailService(IConfiguration config){ _config = config; }
        public async Task SendAsync(string to, string subject, string htmlBody){
            var host = _config["Smtp:Host"]; var port = int.Parse(_config["Smtp:Port"] ?? "25");
            var user = _config["Smtp:User"]; var pass = _config["Smtp:Pass"]; var from = _config["Smtp:From"] ?? "no-reply@postissuemgmt.local";
            var enableSsl = bool.Parse(_config["Smtp:EnableSsl"] ?? "false");
            // Fallback to development outbox if host not configured
            if (string.IsNullOrWhiteSpace(host)){
                Directory.CreateDirectory("outbox");
                var file = Path.Combine("outbox", $"{DateTime.UtcNow:yyyyMMddHHmmss}_{to}_{subject.Replace(' ','_')}.html");
                await File.WriteAllTextAsync(file, htmlBody);
                return;
            }
            using var client = new SmtpClient(host, port){ EnableSsl = enableSsl };
            if (!string.IsNullOrWhiteSpace(user)) client.Credentials = new NetworkCredential(user, pass);
            var mail = new MailMessage(from, to, subject, htmlBody){ IsBodyHtml = true };
            await client.SendMailAsync(mail);
        }
    }
}
