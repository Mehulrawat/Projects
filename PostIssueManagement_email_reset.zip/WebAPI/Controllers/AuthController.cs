using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Application.Interfaces;
using Application.DTO;
using Microsoft.AspNetCore.Authorization;

namespace WebAPI.Controllers {
    [ApiController]
    [Route("auth")]
    public class AuthController : ControllerBase {
        private readonly IAuthService _auth;
        public AuthController(IAuthService auth){ _auth = auth; }

        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterRequestDto dto){
            var (token, user) = await _auth.RegisterAsync(dto);
            return Ok(new { token, user });
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto dto){
            var (token, user) = await _auth.LoginAsync(dto);
            return Ok(new { token, user });
        }

        [HttpGet("me")]
        [Authorize]
        public async Task<IActionResult> Me(){
            var sub = User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
            if (sub == null) return Unauthorized();
            var userId = Guid.Parse(sub);
            var me = await _auth.GetMeAsync(userId);
            return Ok(me);
        }
    }
}

        [HttpGet("verify-email")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyEmail([FromQuery] string token){
            var ok = await _auth.VerifyEmailAsync(token);
            return ok ? Ok(new { verified = true }) : BadRequest(new { verified = false });
        }

        [HttpPost("request-password-reset")]
        [AllowAnonymous]
        public async Task<IActionResult> RequestPasswordReset([FromBody] RequestPasswordResetDto dto){
            var ok = await _auth.RequestPasswordResetAsync(dto);
            return Ok(new { success = ok });
        }

        [HttpPost("reset-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordDto dto){
            var ok = await _auth.ResetPasswordAsync(dto);
            return ok ? Ok(new { reset = true }) : BadRequest(new { reset = false });
        }
