using System;
using System.Linq;
using System.Threading.Tasks;
using Application.DTO;
using Application.Interfaces;
using Application.Exceptions;
using AutoMapper;
using Domain.Entities;
using Domain.Entities.Enums;
using Microsoft.AspNetCore.Identity;

namespace Application.Services {
    public class AuthService : IAuthService {
        private readonly IUnitOfWork _uow;
        private readonly IMapper _mapper;
        private readonly ITokenService _tokenService;
        private readonly IPasswordHasher<User> _hasher;
        private readonly IEmailService _email;
        private readonly int _inactivityDays;

        public AuthService(IUnitOfWork uow, IMapper mapper, ITokenService tokenService, IPasswordHasher<User> hasher, IEmailService email, int inactivityDays = 90){
            _uow = uow; _mapper = mapper; _tokenService = tokenService; _hasher = hasher; _email = email; _inactivityDays = inactivityDays;
        }

        public async Task<(string token, UserDto user)> RegisterAsync(RegisterRequestDto dto){
            var exists = (await _uow.Users.FindAsync(u => u.Email == dto.Email)).FirstOrDefault();
            if (exists != null) throw new ValidationException("Email already registered");
            var user = new User { UserName = dto.UserName, Email = dto.Email };
            user.PasswordHash = _hasher.HashPassword(user, dto.Password);
            // create email verification token
            user.EmailVerificationToken = _tokenService.GenerateRandomToken();
            user.EmailVerificationTokenExpiry = DateTime.UtcNow.AddHours(24);
            await _uow.Users.AddAsync(user);
            // assign USER role by default
            var role = (await _uow.Roles.FindAsync(r => r.Name == RoleNames.User)).FirstOrDefault();
            if (role == null){ role = new Role { Name = RoleNames.User }; await _uow.Roles.AddAsync(role);}            
            await _uow.UserRoles.AddAsync(new UserRole { UserId = user.Id, RoleId = role.Id, User = user, Role = role });
            await _uow.SaveChangesAsync();
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name);
            // send verification email
            var verifyLink = $"{Environment.GetEnvironmentVariable("APP_URL") ?? "http://localhost:5000"}/auth/verify-email?token={user.EmailVerificationToken}";
            await _email.SendAsync(user.Email, "Verify your email", $"<p>Hi {user.UserName},</p><p>Please verify your email by clicking <a href='{verifyLink}'>this link</a>. The link expires in 24 hours.</p>");
            var token = _tokenService.GenerateToken(user, roles);
            var dtoUser = new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles.ToArray(), IsActive = user.IsActive, IsExpired = user.IsExpired };
            return (token, dtoUser);
        }

        public async Task<(string token, UserDto user)> LoginAsync(LoginRequestDto dto){
            var user = (await _uow.Users.FindAsync(u => u.Email == dto.Email)).FirstOrDefault();
            if (user == null) throw new UnauthorizedException("Invalid credentials");
            // inactivity check
            if (user.LastActiveAt.HasValue && user.LastActiveAt.Value < DateTime.UtcNow.AddDays(-_inactivityDays)){
                user.IsExpired = true; user.IsActive = false; _uow.Users.Update(user); await _uow.SaveChangesAsync();
                throw new ForbiddenException("Account expired due to inactivity");
            }
            var res = _hasher.VerifyHashedPassword(user, user.PasswordHash, dto.Password);
            if (res == PasswordVerificationResult.Failed) throw new UnauthorizedException("Invalid credentials");
            if (!user.IsEmailVerified) throw new ForbiddenException("Email not verified");
            user.LastActiveAt = DateTime.UtcNow; _uow.Users.Update(user); await _uow.SaveChangesAsync();
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name);
            // send verification email
            var verifyLink = $"{Environment.GetEnvironmentVariable("APP_URL") ?? "http://localhost:5000"}/auth/verify-email?token={user.EmailVerificationToken}";
            await _email.SendAsync(user.Email, "Verify your email", $"<p>Hi {user.UserName},</p><p>Please verify your email by clicking <a href='{verifyLink}'>this link</a>. The link expires in 24 hours.</p>");
            var token = _tokenService.GenerateToken(user, roles);
            var dtoUser = new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles.ToArray(), IsActive = user.IsActive, IsExpired = user.IsExpired };
            return (token, dtoUser);
        }

        public async Task<UserDto?> GetMeAsync(Guid userId){
            var user = await _uow.Users.GetByIdAsync(userId);
            if (user == null) return null;
            var roles = (await _uow.UserRoles.FindAsync(ur => ur.UserId == user.Id)).Select(ur => ur.Role!.Name).ToArray();
            return new UserDto { Id = user.Id.ToString(), UserName = user.UserName, Email = user.Email, Roles = roles, IsActive = user.IsActive, IsExpired = user.IsExpired };
        }
    }
}

        public async Task<bool> VerifyEmailAsync(string token){
            var user = (await _uow.Users.FindAsync(u => u.EmailVerificationToken == token)).FirstOrDefault();
            if (user == null) return false;
            if (!user.EmailVerificationTokenExpiry.HasValue || user.EmailVerificationTokenExpiry.Value < DateTime.UtcNow) return false;
            user.IsEmailVerified = true; user.EmailVerificationToken = null; user.EmailVerificationTokenExpiry = null;
            _uow.Users.Update(user); await _uow.SaveChangesAsync(); return true;
        }
        public async Task<bool> RequestPasswordResetAsync(RequestPasswordResetDto dto){
            var user = (await _uow.Users.FindAsync(u => u.Email == dto.Email)).FirstOrDefault();
            if (user == null) return true; // avoid user enumeration
            user.PasswordResetToken = _tokenService.GenerateRandomToken();
            user.PasswordResetTokenExpiry = DateTime.UtcNow.AddMinutes(30);
            _uow.Users.Update(user); await _uow.SaveChangesAsync();
            var resetLink = $"{Environment.GetEnvironmentVariable("APP_URL") ?? "http://localhost:5000"}/auth/reset-password?token={user.PasswordResetToken}";
            await _email.SendAsync(user.Email, "Password reset", $"<p>Hi {user.UserName},</p><p>Use <a href='{resetLink}'>this link</a> to reset your password. The link expires in 30 minutes.</p>");
            return true;
        }
        public async Task<bool> ResetPasswordAsync(ResetPasswordDto dto){
            var user = (await _uow.Users.FindAsync(u => u.PasswordResetToken == dto.Token)).FirstOrDefault();
            if (user == null) return false;
            if (!user.PasswordResetTokenExpiry.HasValue || user.PasswordResetTokenExpiry.Value < DateTime.UtcNow) return false;
            user.PasswordHash = _hasher.HashPassword(user, dto.NewPassword);
            user.PasswordResetToken = null; user.PasswordResetTokenExpiry = null;
            _uow.Users.Update(user); await _uow.SaveChangesAsync(); return true;
        }
