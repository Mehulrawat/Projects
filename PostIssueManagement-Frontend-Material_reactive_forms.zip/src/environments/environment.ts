
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:5000' // change if API runs on a different port
};
