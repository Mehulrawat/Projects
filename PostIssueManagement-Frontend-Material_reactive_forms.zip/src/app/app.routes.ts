
import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { PostsListComponent } from './components/posts/posts-list.component';
import { PostDetailComponent } from './components/posts/post-detail.component';
import { PostCreateComponent } from './components/posts/post-create.component';
import { AdminDashboardComponent } from './components/admin/admin-dashboard.component';
import { SuperAdminDashboardComponent } from './components/superadmin/superadmin-dashboard.component';
import { RequestResetComponent } from './components/reset-password/request-reset.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { EmailVerifyComponent } from './components/verify-email/email-verify.component';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

export const appRoutes: Routes = [
  { path: '', component: PostsListComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'verify-email', component: EmailVerifyComponent },
  { path: 'request-password-reset', component: RequestResetComponent },
  { path: 'reset-password', component: ResetPasswordComponent },
  { path: 'posts/create', component: PostCreateComponent, canActivate: [AuthGuard] },
  { path: 'posts/:id', component: PostDetailComponent },
  { path: 'admin', component: AdminDashboardComponent, canActivate: [RoleGuard], data: { roles: ['ADMIN','SUPERADMIN'] } },
  { path: 'superadmin', component: SuperAdminDashboardComponent, canActivate: [RoleGuard], data: { roles: ['SUPERADMIN'] } },
  { path: '**', redirectTo: '' }
];
