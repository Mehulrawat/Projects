
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { ErrorService } from '../services/error.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const errors = inject(ErrorService);
  return next(req).pipe(
    catchError(err => {
      const message = err?.error?.message || err?.statusText || 'Unexpected error';
      errors.set(message);
      return throwError(() => err);
    })
  );
};
