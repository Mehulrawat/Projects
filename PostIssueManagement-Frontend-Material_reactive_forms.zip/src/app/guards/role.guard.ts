
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const RoleGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const roles = route.data?.['roles'] as string[] | undefined;
  const me = auth.currentUser();
  if (!auth.token()) { router.navigate(['/login']); return false; }
  if (me && roles && roles.some(r => me.roles.includes(r))) return true;
  router.navigate(['/']);
  return false;
};
