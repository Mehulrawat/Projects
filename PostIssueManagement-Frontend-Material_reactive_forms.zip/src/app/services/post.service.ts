
import { Injectable } from '@angular/core';
import { ApiHttpService } from './api-http.service';
import { CreatePostDto, PostDto } from '../models/post';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PostService {
  constructor(private api: ApiHttpService){}
  create(dto: CreatePostDto): Observable<PostDto>{ return this.api.post<PostDto>('/posts', dto); }
  submit(id: string){ return this.api.post<PostDto>(`/posts/${id}/submit`, {}); }
  approve(id: string){ return this.api.post<PostDto>(`/posts/${id}/approve`, {}); }
  reject(id: string){ return this.api.post<PostDto>(`/posts/${id}/reject`, {}); }
  assign(id: string, assigneeId: string){ return this.api.post<PostDto>(`/posts/${id}/assign/${assigneeId}`, {}); }
  close(id: string){ return this.api.post<PostDto>(`/posts/${id}/close`, {}); }
  list(status?: string, type?: string){
    const qs = new URLSearchParams(); if (status) qs.set('status', status); if (type) qs.set('type', type);
    const q = qs.toString();
    return this.api.get<PostDto[]>(`/posts${q? ('?'+q):''}`);
  }
  get(id: string){ return this.api.get<PostDto>(`/posts/${id}`); }
}
