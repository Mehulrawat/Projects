
import { Injectable } from '@angular/core';
import { ApiHttpService } from './api-http.service';

@Injectable({ providedIn: 'root' })
export class AdminService {
  constructor(private api: ApiHttpService){}
  promote(userId: string, role: string){ return this.api.post<{success:boolean}>('/admin/promote', { userId, role }); }
  demote(userId: string, role: string){ return this.api.post<{success:boolean}>('/admin/demote', { userId, role }); }
  remove(userId: string){ return this.api.delete<{success:boolean}>(`/admin/users/${userId}`); }
}
