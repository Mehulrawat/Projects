
import { Injectable, signal } from '@angular/core';
import { ApiHttpService } from './api-http.service';
import { LoginRequestDto, RegisterRequestDto, RequestPasswordResetDto, ResetPasswordDto } from '../models/dto';
import { LoginResponse, UserDto } from '../models/user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  token = signal<string | null>(localStorage.getItem('token'));
  currentUser = signal<UserDto | null>(null);

  constructor(private api: ApiHttpService) {
    const t = this.token();
    if (t) this.me().subscribe({ next: u => this.currentUser.set(u) });
  }

  register(dto: RegisterRequestDto){ return this.api.post<LoginResponse>('/auth/register', dto); }
  login(dto: LoginRequestDto){ return this.api.post<LoginResponse>('/auth/login', dto); }
  me(){ return this.api.get<UserDto>('/auth/me'); }

  verifyEmail(token: string){ return this.api.get<{verified:boolean}>(`/auth/verify-email?token=${encodeURIComponent(token)}`); }
  requestPasswordReset(dto: RequestPasswordResetDto){ return this.api.post<{success:boolean}>('/auth/request-password-reset', dto); }
  resetPassword(dto: ResetPasswordDto){ return this.api.post<{reset:boolean}>('/auth/reset-password', dto); }

  setSession(res: LoginResponse){
    localStorage.setItem('token', res.token);
    this.token.set(res.token);
    this.currentUser.set(res.user);
  }
  logout(){ localStorage.removeItem('token'); this.token.set(null); this.currentUser.set(null); }
  hasRole(role: string){ return this.currentUser()?.roles?.includes(role) ?? false; }
}
