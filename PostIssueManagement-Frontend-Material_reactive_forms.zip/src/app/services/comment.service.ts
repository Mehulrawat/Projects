
import { Injectable } from '@angular/core';
import { ApiHttpService } from './api-http.service';
import { CommentDto, CreateCommentDto } from '../models/comment';

@Injectable({ providedIn: 'root' })
export class CommentService {
  constructor(private api: ApiHttpService){}
  add(postId: string, dto: CreateCommentDto){ return this.api.post<CommentDto>(`/comments/${postId}`, dto); }
  list(postId: string){ return this.api.get<CommentDto[]>(`/comments/${postId}`); }
}
