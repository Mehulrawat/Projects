
import { Injectable, signal } from '@angular/core';
@Injectable({ providedIn: 'root' })
export class ErrorService {
  lastError = signal<string | null>(null);
  set(error: string){ this.lastError.set(error); }
  clear(){ this.lastError.set(null); }
}
