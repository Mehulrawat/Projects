
import { Component, computed } from '@angular/core';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { ErrorService } from '../../services/error.service';

@Component({
  selector: 'app-error-banner',
  standalone: true,
  imports: [MatSnackBarModule],
  template: ''
})
export class ErrorBannerComponent {
  error = computed(() => this.errors.lastError());
  constructor(private snack: MatSnackBar, private errors: ErrorService){
    // subscribe via effects - poll-based simple approach
    setInterval(() => {
      const e = this.error();
      if (e) { this.snack.open(e, 'Dismiss', { duration: 4000 }); this.errors.clear(); }
    }, 1000);
  }
}
