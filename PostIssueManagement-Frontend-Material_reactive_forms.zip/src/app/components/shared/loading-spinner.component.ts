
import { Component, computed } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgIf } from '@angular/common';
import { LoadingService } from '../../services/loading.service';

@Component({
  selector: 'app-loading-spinner',
  standalone: true,
  imports: [MatProgressSpinnerModule, NgIf],
  template: `
    @if (loading()) {
      <div class="overlay">
        <mat-progress-spinner mode="indeterminate"></mat-progress-spinner>
      </div>
    }
  `,
  styles: [
    `.overlay{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.1);z-index:1000}`
  ]
})
export class LoadingSpinnerComponent {
  loading = computed(() => this.loadingSvc.loading());
  constructor(private loadingSvc: LoadingService){}
}
