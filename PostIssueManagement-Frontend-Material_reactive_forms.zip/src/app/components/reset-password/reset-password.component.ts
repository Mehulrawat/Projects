
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-reset-password',
  imports: [ReactiveFormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './reset-password.component.html'
})
export class ResetPasswordComponent {
  token='';
  form = this.fb.group({ newPassword: ['', [Validators.required, Validators.minLength(6)]] });
  message: string | null = null;
  constructor(route: ActivatedRoute, private fb: FormBuilder, private auth: AuthService){ this.token = route.snapshot.queryParamMap.get('token') || ''; }
  submit(){
    if (this.form.invalid){ this.form.markAllAsTouched(); return; }
    const { newPassword } = this.form.value;
    this.auth.resetPassword({ token: this.token, newPassword: newPassword! }).subscribe({
      next: r => this.message = r.reset ? 'Password reset successful.' : 'Invalid or expired token.',
      error: _ => this.message = 'Reset failed.'
    });
  }
}
