
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-request-reset',
  imports: [ReactiveFormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './request-reset.component.html'
})
export class RequestResetComponent {
  form = this.fb.group({ email: ['', [Validators.required, Validators.email]] });
  message: string | null = null;
  constructor(private fb: FormBuilder, private auth: AuthService){}
  submit(){
    if (this.form.invalid){ this.form.markAllAsTouched(); return; }
    const { email } = this.form.value;
    this.auth.requestPasswordReset({ email: email! }).subscribe({
      next: _ => this.message = 'If the email exists, a reset link has been sent.',
      error: _ => this.message = 'Request failed.'
    });
  }
}
