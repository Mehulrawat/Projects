
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { PostService } from '../../services/post.service';

@Component({
  standalone: true,
  selector: 'app-admin-dashboard',
  imports: [FormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './admin-dashboard.component.html'
})
export class AdminDashboardComponent {
  pending: any[] = []; assigneeId=''; message: string | null = null;
  constructor(private posts: PostService){ this.load(); }
  load(){ this.posts.list('PendingApproval').subscribe(p => this.pending = p); }
  assign(id: string){ this.posts.assign(id, this.assigneeId).subscribe({ next: _ => this.load(), error: _ => this.message = 'Assign failed' }); }
}
