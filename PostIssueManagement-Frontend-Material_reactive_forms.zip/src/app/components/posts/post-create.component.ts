
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { PostService } from '../../services/post.service';

@Component({
  standalone: true,
  selector: 'app-post-create',
  imports: [ReactiveFormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule],
  templateUrl: './post-create.component.html'
})
export class PostCreateComponent {
  form = this.fb.group({
    title: ['', [Validators.required, Validators.minLength(3)]],
    content: ['', [Validators.required, Validators.minLength(10)]],
    type: ['Announcement', [Validators.required]]
  });
  message: string | null = null;
  constructor(private fb: FormBuilder, private posts: PostService, private router: Router){}
  submit(){
    if (this.form.invalid){ this.form.markAllAsTouched(); return; }
    const { title, content, type } = this.form.value;
    this.posts.create({ title: title!, content: content!, type: type as any }).subscribe({
      next: p => { this.router.navigate(['/posts', p.id]); },
      error: err => { this.message = err?.error?.message || 'Create failed'; }
    });
  }
}
