
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { PostDto } from '../../models/post';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-post-card',
  imports: [MatCardModule, MatButtonModule, RouterLink],
  templateUrl: './post-card.component.html'
})
export class PostCardComponent {
  @Input() post!: PostDto;
  @Output() view = new EventEmitter<string>();
  @Output() approve = new EventEmitter<string>();
  @Output() reject = new EventEmitter<string>();
  @Output() close = new EventEmitter<string>();
  constructor(public auth: AuthService){}
}
