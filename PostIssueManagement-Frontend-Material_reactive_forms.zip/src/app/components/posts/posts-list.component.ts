
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { PostService } from '../../services/post.service';
import { PostDto } from '../../models/post';
import { PostCardComponent } from './post-card.component';

@Component({
  standalone: true,
  selector: 'app-posts-list',
  imports: [FormsModule, RouterLink, MatCardModule, MatFormFieldModule, MatSelectModule, MatButtonModule, PostCardComponent],
  templateUrl: './posts-list.component.html'
})
export class PostsListComponent {
  posts: PostDto[] = []; status=''; type='';
  constructor(public postsService: PostService){ this.load(); }
  load(){ this.postsService.list(this.status, this.type).subscribe(p => this.posts = p); }
}
