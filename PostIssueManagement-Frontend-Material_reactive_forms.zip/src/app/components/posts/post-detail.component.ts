
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { PostService } from '../../services/post.service';
import { CommentService } from '../../services/comment.service';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-post-detail',
  imports: [FormsModule, MatCardModule, MatButtonModule, MatFormFieldModule, MatInputModule],
  templateUrl: './post-detail.component.html'
})
export class PostDetailComponent {
  id=''; post: any; comments: any[] = []; newComment=''; message: string | null = null;
  constructor(route: ActivatedRoute, private posts: PostService, private commentsSvc: CommentService, public auth: AuthService){
    this.id = route.snapshot.params['id'];
    this.load();
  }
  load(){
    this.posts.get(this.id).subscribe(p => this.post = p);
    this.commentsSvc.list(this.id).subscribe(c => this.comments = c);
  }
  submit(){
    this.commentsSvc.add(this.id, { content: this.newComment }).subscribe({
      next: c => { this.newComment = ''; this.comments.unshift(c); },
      error: err => this.message = err?.error?.message || 'Comment failed'
    });
  }
  submitForApproval(){ this.posts.submit(this.id).subscribe(p => this.post = p); }
  approve(){ this.posts.approve(this.id).subscribe(p => this.post = p); }
  reject(){ this.posts.reject(this.id).subscribe(p => this.post = p); }
  close(){ this.posts.close(this.id).subscribe(p => this.post = p); }
}
