
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [ReactiveFormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  form = this.fb.group({
    userName: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });
  message: string | null = null;
  constructor(private fb: FormBuilder, private auth: AuthService){}
  submit(){
    if (this.form.invalid){ this.form.markAllAsTouched(); return; }
    const { userName, email, password } = this.form.value;
    this.auth.register({ userName: userName!, email: email!, password: password! }).subscribe({
      next: res => { this.auth.setSession(res); this.message = 'Registered. Please check your email to verify.'; },
      error: err => { this.message = err?.error?.message || 'Registration failed'; }
    });
  }
}
