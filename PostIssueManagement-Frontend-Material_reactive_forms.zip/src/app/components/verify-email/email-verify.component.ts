
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-email-verify',
  imports: [MatCardModule],
  template: `<mat-card><h2>Email Verification</h2><p>{{message}}</p></mat-card>`
})
export class EmailVerifyComponent {
  message = 'Verifying...';
  constructor(route: ActivatedRoute, auth: AuthService){
    const token = route.snapshot.queryParamMap.get('token') || '';
    auth.verifyEmail(token).subscribe({
      next: r => this.message = r.verified ? 'Email verified. You can now log in.' : 'Invalid or expired token.',
      error: _ => this.message = 'Verification failed.'
    });
  }
}
