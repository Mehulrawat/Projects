
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { AdminService } from '../../services/admin.service';

@Component({
  standalone: true,
  selector: 'app-superadmin-dashboard',
  imports: [FormsModule, MatCardModule, MatFormFieldModule, MatSelectModule, MatInputModule, MatButtonModule],
  templateUrl: './superadmin-dashboard.component.html'
})
export class SuperAdminDashboardComponent {
  userId=''; role='ADMIN'; message: string | null = null;
  constructor(private admin: AdminService){}
  promote(){ this.admin.promote(this.userId, this.role).subscribe({ next: _ => this.message = 'Promoted', error: _ => this.message = 'Failed' }); }
  demote(){ this.admin.demote(this.userId, this.role).subscribe({ next: _ => this.message = 'Demoted', error: _ => this.message = 'Failed' }); }
  remove(){ this.admin.remove(this.userId).subscribe({ next: _ => this.message = 'Removed', error: _ => this.message = 'Failed' }); }
}
