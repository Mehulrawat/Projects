
export type PostStatus = 'Draft'|'PendingApproval'|'Approved'|'Rejected'|'Closed';
export type PostType = 'LostItem'|'HelpRequest'|'Announcement'|'Complaint'|'Issue'|'Other';
export interface PostDto {
  id: string;
  title: string;
  content: string;
  type: PostType;
  status: PostStatus;
  createdByUserId: string;
  assignedToUserId?: string;
  createdAt: string;
  updatedAt?: string;
}
export interface CreatePostDto { title: string; content: string; type: PostType; }
