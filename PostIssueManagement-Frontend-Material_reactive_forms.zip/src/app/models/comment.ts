
export interface CommentDto {
  id: string;
  postId: string;
  createdByUserId: string;
  content: string;
  createdAt: string;
}
export interface CreateCommentDto { content: string; }
