
export interface RegisterRequestDto { userName: string; email: string; password: string; }
export interface LoginRequestDto { email: string; password: string; }
export interface RequestPasswordResetDto { email: string; }
export interface ResetPasswordDto { token: string; newPassword: string; }
