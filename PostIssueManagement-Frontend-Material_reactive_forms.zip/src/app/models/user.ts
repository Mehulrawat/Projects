
export interface UserDto {
  id: string;
  userName: string;
  email: string;
  roles: string[];
  isActive: boolean;
  isExpired: boolean;
}
export interface LoginResponse { token: string; user: UserDto; }
