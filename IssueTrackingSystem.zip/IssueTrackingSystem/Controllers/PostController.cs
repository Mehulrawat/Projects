﻿using IssueTrackingSystem.Database;
using IssueTrackingSystem.Interface;
using IssueTrackingSystem.Model;
using IssueTrackingSystem.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using IssueTrackingSystem.DTO;

namespace IssueTrackingSystem.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class PostController : ControllerBase
    {
        private readonly IPostService _postService;
        private readonly ApplicationDbContext _context;
        public PostController(IPostService postService)
        {
            _postService = postService;

        }

        private static List<Post> issues = new()
        {
            new Post{Id = 1,   Title = "Lost Wallet",Description = "Lost wallet near cafeteria"},
            new Post{Id=2, Title="Coffee Machine",Description="Coffee machine not working"}




  };

        [HttpGet("{id}")]
        public ActionResult<Post> ViewPostById(int id)
        {
            if (id <= 0)
                return NotFound(); // Still works with ActionResult<T>

            var post = _postService.GetPostById(id);
            if (post == null)
            {
                return NotFound(new { Message = "ID not found!" });
            }
            return Ok(post);
        }

        [HttpGet]
        public ActionResult<IEnumerable<Post>> ViewAllPosts()
        {
            List<Post> posts = _postService.GetAllPosts();
            if (posts.IsNullOrEmpty())
            {
                return NotFound(new { Message = "No Posts Available!" });
            }
            return Ok(posts);
        }
        [HttpDelete("{id}")]
        public ActionResult<Post> RemovePostById(int id)

        {
            var removed = _postService.DeletePostById(id);
            if (removed)
            {
                return Ok("Post Deleted!");
            }
            return NotFound(new { Message = "ID not found!" });
        }

        [HttpDelete]
        public ActionResult<Post> RemoveAllPosts()
        {
            var removed = _postService.DeleteAllPosts();
            if (removed)
                return Ok("All Posts Deleted!");
            return BadRequest("Something went wrong!");
        }
       
      




        [HttpPut("{id}")]
        public IActionResult Edit(int id, [FromBody] IssueTrackingSystemDTO dto)
        {
            var post = _postService.EditPost(id,dto);
            if (post == null)
            {
                return NotFound($"Post with ID {id} not found.");
            }

            // Update properties from DTO
           
            return Ok(new
            {
                message = "Post updated successfully",
                post
            });
        }
    }
}
