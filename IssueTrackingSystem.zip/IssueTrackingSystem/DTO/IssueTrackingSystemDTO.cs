﻿namespace IssueTrackingSystem.DTO
{
    public class IssueTrackingSystemDTO
    {

        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }

    }
}
