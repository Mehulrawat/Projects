﻿using IssueTrackingSystem.DTO;
using IssueTrackingSystem.Model;

namespace IssueTrackingSystem.Interface
{
    public interface IPostService
    {
        public Post? GetPostById(int id);
        public List<Post>? GetAllPosts();
        public bool DeletePostById(int id);
        public bool DeleteAllPosts();
        public Post? EditPost(int id,IssueTrackingSystemDTO dto);
    }
}
