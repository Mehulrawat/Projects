﻿namespace IssueTrackingSystem.Service;

    using IssueTrackingSystem.Interface;
using IssueTrackingSystem.Model;
using IssueTrackingSystem.Database;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Mvc;
using IssueTrackingSystem.DTO;
using IssueTrackingSystem.Database;

public class PostService : IPostService
{
   
    private static List<Post> posts = new()
        {
            new Post{Id = 1,   Title = "Lost Wallet",Description = "Lost wallet near cafeteria"},
            new Post{Id=2, Title="Coffee Machine",Description="Coffee machine not working"}




  };
    //private readonly ApplicationDbContext _context;
    //public PostService(ApplicationDbContext context)
    //{
    //    _context = context;
    //}

    public Post? GetPostById(int id)
    {


        var post = posts.FirstOrDefault(i => i.Id == id);
        if (post == null)
            return null;
        return post;
}
    public List<Post>? GetAllPosts()
    {
        if(posts.IsNullOrEmpty())
        {
            return null;
        }
        return posts;
    }

    public bool DeletePostById(int id)
    {
        var post = posts.FirstOrDefault(i => i.Id == id);
        if(post==null)
        {
            return false;
        }
        posts.Remove(post);

        return true;

    }
    public bool DeleteAllPosts()
    {
        posts.Clear();
        if (posts.Count==0)
            return true;
        return false;
    }

    public Post? EditPost(int id,IssueTrackingSystemDTO dto)
    {
        var post = posts.FirstOrDefault(i => i.Id == id);
        if (post == null)
            return null;
        post.Title = dto.Title;
        post.Description = dto.Description;
        if (!string.IsNullOrEmpty(dto.Status))
        {
            post.Status = dto.Status;
        }

        

        return post;
    }
    
}


