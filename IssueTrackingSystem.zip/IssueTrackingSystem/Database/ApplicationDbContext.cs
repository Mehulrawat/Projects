﻿using IssueTrackingSystem.Model;
using Microsoft.EntityFrameworkCore;

namespace IssueTrackingSystem.Database
{
    public class ApplicationDbContext:DbContext
    {

       
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options) { }

            public DbSet<Post> Posts { get; set; }
            //public DbSet<User> Users { get; set; }
        }
    }



